<div class="button-menu-toggle open-menu button-menu-mobile" data-target=".box-menu-nav-mobile">
    <span class="line"></span>
</div>