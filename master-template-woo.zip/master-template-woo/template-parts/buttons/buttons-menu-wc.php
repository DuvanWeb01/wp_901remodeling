<div class="box-buttons-wc">
    <ul class="nav">
        <li class="nav-item"><a href="#" class="nav-link button-icon"><i class="fas fa-user"></i></a></li>
        <li class="nav-item"><a href="#" class="nav-link button-icon"  data-toggle="modal" data-target="#modalSearch"><i class="fas fa-search"></i></a></li>
        <li class="nav-item"><a href="#" class="nav-link button-icon"><i class="fas fa-shopping-cart"></i></a></li>
    </ul>
</div>