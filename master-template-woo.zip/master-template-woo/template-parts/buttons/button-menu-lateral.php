<button class="button-menu-toggle button-menu-lateral open-menu" data-target="#box-menu-lateral">
    <span class="line"></span>
</button>